package com.example.dailynjktracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DairyEntry extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dairy_entry);
    }
}
