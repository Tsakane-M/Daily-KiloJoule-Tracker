package com.example.dailynjktracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.*;

public class Calculator extends AppCompatActivity {

    //CATEGORIES
    TextView exercat = (TextView)findViewById(R.id.exertext);
    TextView foodcat = (TextView) findViewById(R.id.textView3);

    //CATEGORY TYPES
    TextView breakfast = (TextView)findViewById(R.id.breakfast);
    TextView lunch = (TextView)findViewById(R.id.lunch);
    TextView dinner = (TextView)findViewById(R.id.dinner);
    TextView snacks = (TextView)findViewById(R.id.snacks);

    String clickedcat;
    String clickedcattype;

    EditText edittext = ( EditText) findViewById(R.id.editText2);

    //Today
    TextView foodnjk = (TextView)findViewById(R.id.textView11);
    int tdayfoodnjk = 0;
    TextView exernjk = (TextView)findViewById(R.id.textView15);
    int tdayexernjk = 0;

    TextView totalnjk = (TextView)findViewById(R.id.textView19);
    int tdaytotal = 0;

    int passedkjs = 0;

    Handler myhandler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            AddValues(passedkjs);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
    }

    public void ExerCat(View view){
        exercat.setTextColor(Color.parseColor("#52A646"));
        foodcat.setTextColor(Color.parseColor("#000000"));

        breakfast.setText("Gym");
        lunch.setText("Jogging");
        dinner.setText("Yoga");
        snacks.setText("Workout");
        clickedcat = "Exercise";

    }

    public void FoodCat(View view){
        exercat.setTextColor(Color.parseColor("#000000"));
        foodcat.setTextColor(Color.parseColor("#52A646"));

        breakfast.setText("Breakfast");
        lunch.setText("Lunch");
        dinner.setText("Dinner");
        snacks.setText("Snacks");
        clickedcat = "Food";

    }

    public String BreakfastClicked(View view){
        breakfast.setBackgroundResource(R.drawable.selectedcate);
        breakfast.setTextColor(Color.parseColor("#ffffff"));

        lunch.setTextColor(Color.parseColor("#9A9A9A"));
        lunch.setBackgroundResource(R.drawable.nocolorselectedcat);

        dinner.setTextColor(Color.parseColor("#9A9A9A"));
        dinner.setBackgroundResource(R.drawable.nocolorselectedcat);

        snacks.setTextColor(Color.parseColor("#9A9A9A"));
        snacks.setBackgroundResource(R.drawable.nocolorselectedcat);
        clickedcattype = "Breakfast";
        return "Breakfast";
    }

    public String LunchClicked(View view){
        lunch.setBackgroundResource(R.drawable.selectedcate);
        lunch.setTextColor(Color.parseColor("#ffffff"));

        breakfast.setTextColor(Color.parseColor("#9A9A9A"));
        breakfast.setBackgroundResource(R.drawable.nocolorselectedcat);

        dinner.setTextColor(Color.parseColor("#9A9A9A"));
        dinner.setBackgroundResource(R.drawable.nocolorselectedcat);

        snacks.setTextColor(Color.parseColor("#9A9A9A"));
        snacks.setBackgroundResource(R.drawable.nocolorselectedcat);
        clickedcattype = "Lunch";
        return "Lunch";
    }

    public String DinnerClicked(View view){
        dinner.setBackgroundResource(R.drawable.selectedcate);
        dinner.setTextColor(Color.parseColor("#ffffff"));

        lunch.setTextColor(Color.parseColor("#9A9A9A"));
        lunch.setBackgroundResource(R.drawable.nocolorselectedcat);

        breakfast.setTextColor(Color.parseColor("#9A9A9A"));
        breakfast.setBackgroundResource(R.drawable.nocolorselectedcat);

        snacks.setTextColor(Color.parseColor("#9A9A9A"));
        snacks.setBackgroundResource(R.drawable.nocolorselectedcat);
        clickedcattype = "Dinner";
        return "Dinner";
    }

    public String SnacksClicked(View view){
        snacks.setBackgroundResource(R.drawable.selectedcate);
        snacks.setTextColor(Color.parseColor("#ffffff"));

        lunch.setTextColor(Color.parseColor("#9A9A9A"));
        lunch.setBackgroundResource(R.drawable.nocolorselectedcat);

        breakfast.setTextColor(Color.parseColor("#9A9A9A"));
        breakfast.setBackgroundResource(R.drawable.nocolorselectedcat);

        dinner.setTextColor(Color.parseColor("#9A9A9A"));
        dinner.setBackgroundResource(R.drawable.nocolorselectedcat);
        clickedcattype = "Snacks";
        return "Snacks";
    }

    public void EnterClicked(){
        Runnable r = new Runnable() {
            @Override
            public void run() {
                synchronized (this){
                    try{
                        if(android.text.TextUtils.isDigitsOnly(edittext.getText().toString())){
                            int kjs = Integer.parseInt(edittext.getText().toString());
                            passedkjs = kjs; // AddValues(kjs);
                        }
                        else{
                            int kjs = 0;
                        }
                    }
                    catch (Exception e){}
                }
                myhandler.sendEmptyMessage(0);
            }
        };
        Thread mythread = new Thread();
        mythread.start();

    }

    public void AddValues(int value){
        if(clickedcat.equals("Food")){
            tdayfoodnjk = tdayfoodnjk+value;
        }
        else{
            tdayexernjk = tdayexernjk+value;
        }

        tdaytotal = tdayexernjk+tdayfoodnjk;

        foodnjk.setText(tdayfoodnjk+" NJK");
        exernjk.setText(tdayexernjk+" NJK");
        totalnjk.setText(tdaytotal+" NJK");
    }
}
